var tela = 1

var y = 150;
var fundo;
controle = false

function setup () {
  createCanvas (1000,600)
  fundo = loadImage('fundo.png');
  instrucoes = loadImage('instruções_.png');
  creditos = loadImage('créditos___.png');
}

function draw() {
  //tela do menu...
  if(tela ===1){
    background(fundo);
    textSize(25);
    textAlign(CENTER)
    
    noStroke();
    fill(70,130,180);
    rect(110,y,180,30);
    
    fill(800);
    text('JOGAR',200,173);
    text('INSTRUÇÕES',200,223);
    text('CRÉDITOS', 200,273);
    
   
    if(keyIsPressed ===false) {
      controle = false; }
    if (controle ===false){
      if(keyIsDown (UP_ARROW) && (y <= 250 && y>150)){
       y -= 50;
      controle = true;
      }
    if(keyIsDown(ENTER) && y === 150) {
     tela = 2;
      controle = true;
    }  
      else if (keyIsDown (ENTER) && y === 200) {
        tela = 3;
        controle = true;
      }
      else if (keyIsDown (ENTER) && y === 250) {
        tela = 4 
        controle = true
      }
      
      if ( keyIsDown (DOWN_ARROW) && (y < 250 && y >= 150)) {
        y += 50
        controle = true
      }
    }
  }

  //EM JOGO...
  else if (tela === 2){
    background (fundo);
    textSize (20)
    textAlign (CENTER)
    
    fill (70,130,180);
    text ('Aperta Esc para voltar!', 180,380);
    fill (70,130,180);
    rect (80,190,230,40);
    fill (255,250,250);
    text ('JOGANDO...', 200,220);
    
    if (keyIsDown (ESCAPE)) {
      tela = 1
    }
  }
  
  //Instruções...
  else if (tela === 3) {
    background (instrucoes);
    textSize(14)
    
    if(keyIsDown(ESCAPE)){
      tela = 1
    }
  }
  
  // Créditos...
  else if (tela === 4) {
    background (creditos)
  
    if (keyIsDown (ESCAPE)) { tela =1}
  }
}